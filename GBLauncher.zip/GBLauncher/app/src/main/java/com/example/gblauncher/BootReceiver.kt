package com.example.gblauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.lockOn(c) || Prefs.lcdOn(c)) GbService.sync(c)
    }
}
