package com.example.gblauncher

import android.app.Activity
import android.app.KeyguardManager
import android.app.NotificationManager
import android.os.*
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.*

class LockActivity : Activity() {
    private val pin = StringBuilder()
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var dots: TextView
    private lateinit var msg: TextView
    private var fails = 0
    private var until = 0L

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            date.text = SimpleDateFormat("EEE dd MMM", Locale.getDefault()).format(now).uppercase()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (!Prefs.hasPin(this)) { finish(); return }
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        getSystemService(NotificationManager::class.java).cancel(2)
        window.statusBarColor = Px.C3
        window.navigationBarColor = Px.C3

        val d = { v: Int -> Px.dp(this, v) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Px.C3)
        }
        clock = PxText(this).apply { textSize = 56f; gravity = Gravity.CENTER }
        date = PxText(this).apply { textSize = 14f; gravity = Gravity.CENTER }
        dots = PxText(this).apply { textSize = 26f; gravity = Gravity.CENTER }
        msg = PxText(this).apply { textSize = 12f; gravity = Gravity.CENTER }
        root.addView(clock)
        root.addView(date)
        root.addView(dots, LinearLayout.LayoutParams(Px.MATCH, Px.WRAP).apply { topMargin = d(24) })
        root.addView(msg, LinearLayout.LayoutParams(Px.MATCH, Px.WRAP).apply { bottomMargin = d(12) })

        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "DEL", "0", "OK")
        for (r in 0 until 4) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
            for (c in 0 until 3) {
                val k = keys[r * 3 + c]
                row.addView(Px.btn(this, k) { press(k) },
                    LinearLayout.LayoutParams(d(76), d(60)).apply { setMargins(d(5), d(5), d(5), d(5)) })
            }
            root.addView(row)
        }
        setContentView(root)
        renderDots()
    }

    private fun press(k: String) {
        when (k) {
            "DEL" -> if (pin.isNotEmpty()) pin.setLength(pin.length - 1)
            "OK" -> submit()
            else -> if (pin.length < 8) pin.append(k)
        }
        renderDots()
    }

    private fun submit() {
        val now = SystemClock.elapsedRealtime()
        if (now < until) {
            msg.text = "WAIT ${(until - now) / 1000 + 1}s"
        } else if (Prefs.check(this, pin.toString())) {
            fails = 0
            unlock()
        } else {
            fails++
            msg.text = "WRONG PIN"
            if (fails >= 5) { until = now + 30_000; fails = 0; msg.text = "LOCKED 30s" }
        }
        pin.setLength(0)
    }

    private fun unlock() {
        val km = getSystemService(KeyguardManager::class.java)
        if (km.isKeyguardLocked) {
            km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() { finish() }
            })
        } else finish()
    }

    private fun renderDots() {
        dots.text = (0 until maxOf(4, pin.length)).joinToString(" ") { if (it < pin.length) "#" else "-" }
    }

    override fun onNewIntent(intent: android.content.Intent?) {
        super.onNewIntent(intent)
        pin.setLength(0)
        msg.text = ""
        renderDots()
    }

    override fun onResume() { super.onResume(); ui.post(tick) }
    override fun onPause() { ui.removeCallbacks(tick); super.onPause() }
    override fun onBackPressed() {}
}
