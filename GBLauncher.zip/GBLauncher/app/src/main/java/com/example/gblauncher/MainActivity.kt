package com.example.gblauncher

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private class App(val label: String, val pkg: String, val launch: Intent, val icon: Bitmap)

    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val cache = HashMap<String, Bitmap>()
    private var apps: List<App> = emptyList()
    private lateinit var grid: GridView
    private lateinit var clock: TextView
    private lateinit var lcdBtn: TextView

    private fun d(v: Int) = Px.dp(this, v)

    private val appAdapter = object : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(p: Int) = apps[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup): View {
            val a = apps[p]
            val cell = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, d(6), 0, d(6))
                val iv = ImageView(context).apply {
                    background = Px.box(context, Px.C2)
                    setPadding(d(5), d(5), d(5), d(5))
                    scaleType = ImageView.ScaleType.FIT_CENTER
                }
                addView(iv, LinearLayout.LayoutParams(d(60), d(60)))
                val t = PxText(context).apply {
                    textSize = 9f
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.CENTER
                }
                addView(t, LinearLayout.LayoutParams(Px.MATCH, Px.WRAP).apply { topMargin = d(4) })
            }
            (cell.getChildAt(0) as ImageView).setImageDrawable(Px.draw(this@MainActivity, a.icon))
            (cell.getChildAt(1) as TextView).text = a.label.uppercase()
            return cell
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val pct = b?.let {
                it.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / maxOf(1, it.getIntExtra(BatteryManager.EXTRA_SCALE, 100))
            } ?: 0
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) + "  " + pct + "%"
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Px.C0
        window.navigationBarColor = Px.C0

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Px.C3) }

        val head = LinearLayout(this).apply {
            setBackgroundColor(Px.C0)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(d(14), d(10), d(14), d(10))
        }
        head.addView(PxText(this).apply { text = "GB LAUNCHER"; textSize = 14f; setTextColor(Px.C3) },
            LinearLayout.LayoutParams(0, Px.WRAP, 1f))
        clock = PxText(this).apply { textSize = 14f; setTextColor(Px.C3); gravity = Gravity.END }
        head.addView(clock)
        root.addView(head, LinearLayout.LayoutParams(Px.MATCH, Px.WRAP))

        grid = GridView(this).apply {
            numColumns = 4
            adapter = appAdapter
            selector = ColorDrawable(Color.TRANSPARENT)
            verticalSpacing = d(4)
            setPadding(d(8), d(8), d(8), d(8))
            clipToPadding = false
            setOnItemClickListener { _, _, p, _ ->
                try { startActivity(apps[p].launch) } catch (e: Exception) { toast("CAN'T OPEN") }
            }
            setOnItemLongClickListener { _, _, p, _ -> menu(apps[p]); true }
        }
        root.addView(grid, LinearLayout.LayoutParams(Px.MATCH, 0, 1f))

        val bar = LinearLayout(this).apply { setBackgroundColor(Px.C0); setPadding(d(8), d(8), d(8), d(8)) }
        lcdBtn = Px.btn(this, "") { toggleLcd() }
        val buttons = listOf(Px.btn(this, "LOCK") { lockNow() }, lcdBtn,
            Px.btn(this, "SET") { startActivity(Intent(this, SettingsActivity::class.java)) })
        for (b in buttons) bar.addView(b, LinearLayout.LayoutParams(0, Px.WRAP, 1f).apply { setMargins(d(4), 0, d(4), 0) })
        root.addView(bar, LinearLayout.LayoutParams(Px.MATCH, Px.WRAP))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refreshLcd()
        loadApps()
        ui.post(tick)
    }

    override fun onPause() { ui.removeCallbacks(tick); super.onPause() }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        grid.setSelection(0)
    }

    override fun onBackPressed() {} // it's a launcher: back does nothing

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun refreshLcd() { lcdBtn.text = "LCD " + if (Prefs.lcdOn(this)) "ON" else "OFF" }

    private fun toggleLcd() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        Prefs.setLcdOn(this, !Prefs.lcdOn(this))
        GbService.sync(this)
        refreshLcd()
    }

    private fun lockNow() {
        if (!Prefs.hasPin(this)) { toast("SET A PIN FIRST (SET)"); return }
        val dpm = getSystemService(DevicePolicyManager::class.java)
        if (dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java)) && Prefs.lockOn(this)) dpm.lockNow()
        else startActivity(Intent(this, LockActivity::class.java))
    }

    private fun menu(a: App) {
        AlertDialog.Builder(this).setTitle(a.label).setItems(arrayOf("APP INFO", "UNINSTALL")) { _, w ->
            val u = Uri.fromParts("package", a.pkg, null)
            startActivity(if (w == 0) Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, u) else Intent(Intent.ACTION_DELETE, u))
        }.show()
    }

    private fun loadApps() {
        exec.execute {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    val pkg = ri.activityInfo.packageName
                    val bmp = synchronized(cache) { cache[pkg] }
                        ?: Px.pixelate(Px.toBitmap(ri.loadIcon(pm), 96)).also { synchronized(cache) { cache[pkg] = it } }
                    val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                        .setClassName(pkg, ri.activityInfo.name)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                    App(ri.loadLabel(pm).toString(), pkg, launch, bmp)
                }
                .sortedBy { it.label.lowercase() }
            ui.post { apps = list; appAdapter.notifyDataSetChanged() }
        }
    }
}
