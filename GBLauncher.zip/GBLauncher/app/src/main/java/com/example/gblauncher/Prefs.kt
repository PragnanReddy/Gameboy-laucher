package com.example.gblauncher

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("gb", Context.MODE_PRIVATE)
    fun lockOn(c: Context) = sp(c).getBoolean("lock", false)
    fun lcdOn(c: Context) = sp(c).getBoolean("lcd", false)
    fun setLockOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("lock", v).apply()
    fun setLcdOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("lcd", v).apply()
    fun hasPin(c: Context) = sp(c).contains("hash")

    private fun hash(salt: ByteArray, pin: String): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 50000, 256)).encoded

    fun setPin(c: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp(c).edit()
            .putString("salt", Base64.encodeToString(salt, 0))
            .putString("hash", Base64.encodeToString(hash(salt, pin), 0))
            .apply()
    }

    fun check(c: Context, pin: String): Boolean {
        val s = sp(c)
        val salt = Base64.decode(s.getString("salt", ""), 0)
        val h = Base64.decode(s.getString("hash", ""), 0)
        return h.isNotEmpty() && MessageDigest.isEqual(h, hash(salt, pin))
    }
}
