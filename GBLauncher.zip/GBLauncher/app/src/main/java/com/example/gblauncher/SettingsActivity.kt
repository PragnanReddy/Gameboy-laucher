package com.example.gblauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast

class SettingsActivity : Activity() {
    private lateinit var box: LinearLayout
    private fun d(v: Int) = Px.dp(this, v)
    private val dpm get() = getSystemService(DevicePolicyManager::class.java)
    private val admin get() = ComponentName(this, AdminReceiver::class.java)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = Px.C0
        window.navigationBarColor = Px.C0
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(14), d(14), d(14), d(14)) }
        setContentView(ScrollView(this).apply { setBackgroundColor(Px.C3); addView(box) })
    }

    override fun onResume() { super.onResume(); render() }

    private fun onOff(b: Boolean) = if (b) "ON" else "OFF"

    private fun row(label: String, click: () -> Unit) {
        val b = Px.btn(this, label, click).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL }
        box.addView(b, LinearLayout.LayoutParams(Px.MATCH, Px.WRAP).apply { setMargins(0, d(6), 0, d(6)) })
    }

    private fun render() {
        box.removeAllViews()
        box.addView(PxText(this).apply { text = "SETTINGS"; textSize = 20f })
        row("PIN  [${if (Prefs.hasPin(this)) "SET" else "NONE"}]") { askPin() }
        row("GB LOCK SCREEN  [${onOff(Prefs.lockOn(this))}]") { toggleLock() }
        row("LCD PIXEL FILTER  [${onOff(Prefs.lcdOn(this))}]") { toggleLcd() }
        row("OVERLAY PERMISSION  [${if (Settings.canDrawOverlays(this)) "OK" else "NO"}]") { overlayPerm() }
        row("DEVICE ADMIN (LOCK BTN)  [${onOff(dpm.isAdminActive(admin))}]") { toggleAdmin() }
        row("SET AS HOME APP") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun askPin() {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        AlertDialog.Builder(this).setTitle("NEW PIN (4-8 DIGITS)").setView(et)
            .setPositiveButton("SAVE") { _, _ ->
                val p = et.text.toString()
                if (p.length in 4..8) { Prefs.setPin(this, p); render() } else toast("4-8 DIGITS")
            }.setNegativeButton("CANCEL", null).show()
    }

    private fun overlayPerm() =
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))

    private fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun toggleLock() {
        if (!Prefs.hasPin(this)) { toast("SET A PIN FIRST"); return }
        if (!Settings.canDrawOverlays(this)) { overlayPerm(); return }
        Prefs.setLockOn(this, !Prefs.lockOn(this))
        askNotif()
        GbService.sync(this)
        render()
    }

    private fun toggleLcd() {
        if (!Settings.canDrawOverlays(this)) { overlayPerm(); return }
        Prefs.setLcdOn(this, !Prefs.lcdOn(this))
        askNotif()
        GbService.sync(this)
        render()
    }

    private fun toggleAdmin() {
        if (dpm.isAdminActive(admin)) { dpm.removeActiveAdmin(admin); render(); return }
        startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Lets the LOCK button turn the screen off."))
    }
}
