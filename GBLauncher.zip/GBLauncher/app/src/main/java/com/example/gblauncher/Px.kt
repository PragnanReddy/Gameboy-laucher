package com.example.gblauncher

import android.content.Context
import android.graphics.*
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.TextView

/** Retro helpers: Game Boy palette, pixelation, hard-edged widgets. */
object Px {
    const val MATCH = -1
    const val WRAP = -2
    val C0 = 0xFF0F380F.toInt() // darkest
    val C1 = 0xFF306230.toInt()
    val C2 = 0xFF8BAC0F.toInt()
    val C3 = 0xFF9BBC0F.toInt() // lightest
    private val SHADES = intArrayOf(C0, C1, C2, C3)
    private val BAYER = arrayOf(intArrayOf(0, 2), intArrayOf(3, 1))

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    /** Drop a pixel font at res/font/pixel.ttf (e.g. Press Start 2P) and it is picked up automatically. */
    fun typeface(c: Context): Typeface {
        val id = c.resources.getIdentifier("pixel", "font", c.packageName)
        return if (id != 0) c.resources.getFont(id) else Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    }

    fun toBitmap(d: Drawable, size: Int): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, size, size)
        d.draw(Canvas(b))
        return b
    }

    /** Downscale to grid x grid, then map to 4 green shades with 2x2 ordered dithering. */
    fun pixelate(src: Bitmap, grid: Int = 20): Bitmap {
        val small = Bitmap.createScaledBitmap(src, grid, grid, true)
        val px = IntArray(grid * grid)
        small.getPixels(px, 0, grid, 0, 0, grid, grid)
        val lum = IntArray(px.size) { i ->
            val p = px[i]
            (0.3 * Color.red(p) + 0.59 * Color.green(p) + 0.11 * Color.blue(p)).toInt()
        }
        var lo = 255
        var hi = 0
        for (i in px.indices) if (Color.alpha(px[i]) > 127) { lo = minOf(lo, lum[i]); hi = maxOf(hi, lum[i]) }
        val range = maxOf(1, hi - lo).toFloat()
        val out = IntArray(px.size)
        for (i in px.indices) {
            if (Color.alpha(px[i]) < 128) { out[i] = Color.TRANSPARENT; continue }
            val x = i % grid
            val y = i / grid
            val v = (lum[i] - lo) / range * 3f + (BAYER[y % 2][x % 2] / 4f - 0.375f)
            out[i] = SHADES[(v + 0.5f).toInt().coerceIn(0, 3)]
        }
        return Bitmap.createBitmap(out, grid, grid, Bitmap.Config.ARGB_8888)
    }

    /** Drawable that scales up with nearest-neighbour so pixels stay square and sharp. */
    fun draw(c: Context, bmp: Bitmap): Drawable {
        val d = BitmapDrawable(c.resources, bmp)
        d.setFilterBitmap(false)
        d.setAntiAlias(false)
        return d
    }

    fun box(c: Context, fill: Int, stroke: Int = C0, w: Int = 2) = GradientDrawable().apply {
        setColor(fill)
        setStroke(dp(c, w), stroke)
    }

    fun btn(c: Context, label: String, click: () -> Unit) = PxText(c).apply {
        text = label
        textSize = 13f
        gravity = Gravity.CENTER
        setPadding(dp(c, 10), dp(c, 10), dp(c, 10), dp(c, 10))
        background = box(c, C2)
        setOnClickListener { click() }
    }
}

/** TextView with anti-aliasing off so any font renders hard-edged. */
class PxText(c: Context) : TextView(c) {
    init {
        typeface = Px.typeface(c)
        setTextColor(Px.C0)
        includeFontPadding = false
    }
    override fun onDraw(canvas: Canvas) {
        paint.isAntiAlias = false
        paint.isSubpixelText = false
        super.onDraw(canvas)
    }
}
