package com.example.gblauncher

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
