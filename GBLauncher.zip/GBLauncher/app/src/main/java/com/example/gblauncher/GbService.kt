package com.example.gblauncher

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.View
import android.view.WindowManager

/** One foreground service: shows the GB lock screen on screen-off and draws the LCD pixel-grid overlay. */
class GbService : Service() {
    private var overlay: View? = null

    private val offReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (Prefs.lockOn(c) && Prefs.hasPin(c)) showLock(c)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gb", "GB Launcher", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("gblock", "GB Lock", NotificationManager.IMPORTANCE_HIGH))
        val n = Notification.Builder(this, "gb")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("GB LAUNCHER ACTIVE")
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST)
        else startForeground(1, n)
        registerReceiver(offReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        sync()
        return START_STICKY
    }

    private fun sync() {
        if (Prefs.lcdOn(this) && Settings.canDrawOverlays(this)) {
            if (overlay == null) addOverlay()
        } else removeOverlay()
        if (!Prefs.lockOn(this) && !Prefs.lcdOn(this)) stopSelf()
    }

    private fun addOverlay() {
        val lp = WindowManager.LayoutParams(
            Px.MATCH, Px.MATCH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        val v = LcdView(this)
        getSystemService(WindowManager::class.java).addView(v, lp)
        overlay = v
    }

    private fun removeOverlay() {
        overlay?.let { try { getSystemService(WindowManager::class.java).removeView(it) } catch (_: Exception) {} }
        overlay = null
    }

    override fun onDestroy() {
        try { unregisterReceiver(offReceiver) } catch (_: Exception) {}
        removeOverlay()
        super.onDestroy()
    }

    companion object {
        fun sync(c: Context) = c.startForegroundService(Intent(c, GbService::class.java))

        fun showLock(c: Context) {
            val i = Intent(c, LockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            val pi = PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(c, "gblock")
                .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
                .setContentTitle("LOCKED")
                .setFullScreenIntent(pi, true)
                .setAutoCancel(true)
                .build()
            c.getSystemService(NotificationManager::class.java).notify(2, n)
            try { c.startActivity(i) } catch (_: Exception) {}
        }
    }
}

/** LCD look: faint pixel grid + green tint over everything. Touches pass straight through. */
class LcdView(c: Context) : View(c) {
    private val paint = Paint()
    init {
        val cell = Px.dp(c, 3).coerceAtLeast(3)
        val t = Bitmap.createBitmap(cell, cell, Bitmap.Config.ARGB_8888)
        for (k in 0 until cell) { t.setPixel(k, cell - 1, 0x40000000); t.setPixel(cell - 1, k, 0x40000000) }
        paint.shader = BitmapShader(t, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }
    override fun onDraw(cv: Canvas) {
        cv.drawColor(0x1E306230)
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }
}
